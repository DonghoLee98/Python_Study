import sys
args = sys.argv[1:]     # sys.argv는 List를 반환한다. 스크립트 명 이후 사용자 전달 인수들이 나열된다.
for i in args:
    # print(i.upper(), end=' ')
    print(i)
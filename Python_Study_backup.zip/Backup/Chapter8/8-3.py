
# 정규 표현식 - Enhanced

# 앞의 +, *, [], {} 등의 메타문자는 Match가 성사되면 문자열을 탐색하는 시작 위치가 변경된다.
# == 소비된다, 고 표현한다. (aac <-- a+ 패턴 찾아야 할 때 aa 가 매치되고 나면 aa는 소비되고, c가 match 시작 위치가 된다.)
# 이러한 '소비' 가 없는 메타문자를 학습한다.
import re

# |     == or
'''
p = re.compile('Crow|Servo')
print(p.match('CrowHello'))     # <re.Match object; span=(0, 4), match='Crow'>
print(p.match('ServoHello'))    # <re.Match object; span=(0, 5), match='Servo'>
'''

# ^     : 문자열의 맨 처음과 일치한다는 것을 의미 (re.MULTILINE 사용 시 각 줄의 시작과 일치하는지 확인한다.)
'''
print(re.search('^Life', 'Life is too short'))  # <re.Match object; span=(0, 4), match='Life'>
print(re.search('^Life', 'My Life'))            # None
'''

# $     : 문자열의 맨 끝과 일치한다는 것을 의미
'''
print(re.search('short$', 'Life is too short'))                     # <re.Match object; span=(12, 17), match='short'>
print(re.search('short$', 'Life is too short, you need python'))    # None
'''

# \A    : \A 는 줄과 상관없이 전체 문자열의 처음하고만 Match된다. (^와 동일한 의미이나 re.MULTILINE 사용해도 줄마다 처음을 체크하지 않는다.)

# \Z    : \Z 는 줄과 상관없이 전체 문자열의 마지막하고만 Match된다. ($와 동일한 의미이나 re.MULTILINE 사용 시 "전체" 문자열의 마지막을 체크한다.)

# \b    : 단어 구분자 (word boundary), 보통 단어는 whitespace에 의해 구분된다.
'''
p = re.compile(r'\bclass\b')        # class를 search 하며 class 앞뒤로 whitespace가 있을 때 match된다.
print(p.search('no class at all'))  # <re.Match object; span=(3, 8), match='class'>
'''

# \B    : \b 문자와 반대의 경우이다. ( = whitespace로 구분되지 않은 경우를 말한다.)
'''
p = re.compile(r'\Bclass\B')        # class 앞뒤로 공백이 하나라도 있다면 match되지 않는다.
print(p.search('no class at all'))              # None
print(p.search('the disclassified algorithm'))  # <re.Match object; span=(7, 12), match='class'>
print(p.search('one subclass is'))              # None
'''

# 그룹핑    : 그룹으로 묶어줄 문자열을 () 로 감싸준다.
# 예시 : ABC 가 반복되는지 조사하는 정규식
'''
p = re.compile('(ABC)+')    # <- 'ABC+' 라면 C가 반복되는지 확인하게 된다.
m = p.search('ABCABCABC ok?')
print(m)    # <re.Match object; span=(0, 9), match='ABCABCABC'>

# 그룹핑 추가 예시
# (\w) 처럼 이름 부분을 group으로 만든다. --> match 객체에서의 group에 대한 Method 사용 가능
# (\d+[-]\d+[-]\d+) 전화번호 부분을 group으로 만든다.
# ((\d+)[-]\d+[-]\d+) 전화번호 중 국번 부분을 중복 group으로 만든다.
p = re.compile(r"(\w+)\s+((\d+)[-]\d+[-]\d+)")    # \w : 문자 반복 \s : 공백 반복 \d : 숫자 반복 ( = 이름 + " " + 전화번호)
m = p.search("park 010-1234-1234")
print(m.group(1))   # park
# group()   : group(0) : 매치된 전체 문자열 
#             group(n) : n 번째 그룹에 해당하는 문자열
print(m.group(2))   # 010-1234-1234
print(m.group(3))   # 010
# 중첩 group의 경우 바깥에서 안쪽으로 들어갈수록 인덱스 값이 증가한다.
'''

# 그룹핑 문자열 재참조하기
'''
# \1 : 첫 번째 group을 재참조 한다는 뜻이다. (\2, \3, ... 으로 두, 세 번째... 그룹을 참조할 수 있다.)
p = re.compile(r'(\b\w+)\s+\1')
print(p.search('Paris in the the spring').group())  # the the
'''

# 그룹핑된 문자열 이름 붙이기
'''
# 그룹이 수정되면 해당 그룹을 참조한 부분의 index를 모두 변경해 주어야 하기 때문에
# index가 아닌 이름으로 원하는 그룹을 참조할 수 있도록 한다.
# ?P<name> 을 그룹 맨 앞에 붙여주면 된다.
# .group("name") 과 같이 사용하면된다.
p = re.compile((r"(?P<name>\w+)\s+((\d+)[-]\d+[-]\d+)"))
m = p.search("park 010-1234-1234")
print(m.group("name"))  # park

# 아래와 같이 재참조도 가능하다.
p = re.compile((r'(?P<word>\b\w+)\s+(?P=word)'))
print(p.search('Paris in the the spring').group())  # the the

# --> (?...) 표현식은 정규 표현식의 확장 구문으로써 가독성은 떨어지나, 강력한 기능을 제공한다.
'''

# 전방 탐색
'''
# 예시
# p = re.compile(".+:")
# m = p.search("http://www.google.com")
# print(m.group())    # http:
# 여기서 ':' 을 검색에는 포함하나, match 결과물에는 포함하고 싶지 않을 때 전방 탐색을 사용한다.

# --> (?=:) 으로 처리하면 전방 탐색을 구현할 수 있다.(?= 뒤의 검색어는 소비되지 않는다.)
p = re.compile(".+(?=:)")
m = p.search("http://www.google.com")
print(m.group())    # http  <-- : 가 제외됨을 확인할 수 있다.

# 긍정형 : (?= ~ )  --> ~ 는 정규식과 match O , 문자열 소비 X
# 부정형 : (?! ~ )  --> ~ 는 정규식과 match X , 문자열 소비 X

# 부정형 전방 탐색 예시 - 검색 간 특정 확장자 제외
p = re.compile(".*[.](?!bat$|exe$).*$", re.MULTILINE)
l = p.findall("""
autoexec.exe
autoexec.bat
autoexec.jpg
autoexec.raw
""")
print(l)    # ['autoexec.jpg', 'autoexec.raw']
'''

# 문자열 바꾸기 : 정규식과 매치되는 부분을 다른 문자로 바꿀 수 있다.
# sub() Method를 사용한다.
'''
p = re.compile('(blue|white|red)')
# print(p.sub('colour', 'blue socks and red shoes'))  # colour socks and colour shoes (blue와 red가 colour로 변경되었다.)
print(p.sub('colour', 'blue socks and red shoes', count=1)) # count=1 : 한 번만 바꾸겠다 --> 앞의 blue만 colour로 변경된다.
'''

# sub 메서드에서 참조 구문 활용하기
'''
p = re.compile(r"(?P<name>\w+)\s+(?P<phone>(\d+)[-]\d+[-]\d+)")
print(p.sub("\g<phone> \g<name>", "park 010-1234-1234"))
# --> 010-1234-1234 park    name 말고 index를 넣을 수도 있다.
'''

# sub 메서드의 매개변수로 함수 넣기
'''
def hexrepl(match):     # match 객체를 인자로 받는다.
    value = int(match.group())
    return hex(value)

p = re.compile(r'\d+')
print(p.sub(hexrepl, 'Call 65490 for printing, 49152 for user code'))
# sub()의 첫 번째 인자로 '함수'를 사용하게 될 경우, match된 객체가 입력된다. --> 입력된 문자열은 함수의 return 값으로 바뀌게 된다.
# --> Call 0xffd2 for printing, 0xc000 for user code
'''

# greedy와 non-greedy
# 탐욕스러운? 무슨 말인지 알아보자
s = '<html><head><title>Title</title>'
print(re.match('<.*>', s).group())
# --> <html><head><title>Title</title>
#     앞의 <html>만 match될 것이라는 예상과는 달리, 첫 꺽쇠< 와 마지막 꺽쇠> 가 잡힌다
#     욕심이 그득하다 해서 greedy 라고 한다.

# non-greedy 하게 출력하기 위해 아래와 같이 작성한다.
print(re.match('<.*?>', s).group()) # * 뒤에 ? 를 붙여준다.
# --> <html>    앞의 <html> 만 출력되는 것을 확인할 수 있다.

# non-greedy 문자는 아래와 같이 사용 가능하다.
# *?, +?, ??, {m,n}?
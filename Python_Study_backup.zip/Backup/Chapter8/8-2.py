
# 정규 표현식 시작하기

# 메타 문자(Meta Characters) 를 사용한다.
# 메타 문자란? : 특별한 의미를 가진 문자
# 메타 문자 예시 : . ^ $ * + ? { } [ ] \ | ( )


# 문자 클래스 [ ]
'''
[abc]

 - [] 사이의 문자들과 매치
 - "a"는 정규식과 일치하는 문자인 "a"가 있으므로 매치
 - "before" --> "b" 매치
 - "dude" --> 매치 X
 - 하이픈을 사용하여 From ~ To 표현 가능
    ex) [a-c] = [abc], [0-5] = [012345]
'''

# Dot (.)
'''
a.b

 - 줄바꿈(\n)을 제외한 모든 문자와 매치
 - "aab"는 가운데 문자 "a"가 모든 문자를 의미하는 '.' 과 잎치하므로 정규식과 매치
 - "a0b" --> "0"와 '.' 매치
 - "abc" --> "a" 문자와 "b" 문자 사이에 어떤 문자라도 하나 있어야 하므로, 매치 X
'''

# 반복 (*)  0회 반복 인정
'''
ca*t

 - "ct"는 "a"가 0번 반복되어 매치
 - "cat"는 "a"가 1번 반복되어 매치      (1번 반복)
 - "caaat"는 "a"가 3번 반복되어 매치    (3번 반복)
'''

# 반복 (+)  최소 1회 이상 반복
'''
ca+t

 - "ct"는 "a"가 0번 반복되어 매치 X     (최소 1회 반복 필요)
 - "cat"는 "a"가 1번 반복되어 매치      (1번 반복)
 - "caaat"는 "a"가 3번 반복되어 매치    (3번 반복)
'''

# 반복 ({m,n}, ?)
'''
ca{2}t      : 반복 횟수를 지정

 - "cat"는 "a"가 1 번만 반복되어 매치 X
 - "caat"는 "a"가 2 번 반복되어 매치        (2번 반복)
 
ca{2, 5}t   : 반복 범위를 지정

 - "cat"는 "a"가 1 번만 반복되어 매치 X
 - "caat"는 "a"가 2 번 반복되어 매치        (2번 반복)
 - "caaaaat"는 "a"가 5 번 반복되어 매치     (5번 반복)

ab?c        : {0, 1}, 다시 말해 없거나 있어도(1 개) 된다

 - "abc"는 "b"가 1 번 사용되어 매치
 - "ac"는 "b"가 0 번 사용되어 매치
'''


# re모듈    <- 파이썬에서 정규 표현식을 지원하는 표준 라이브러리 이다.
'''
# re : regular expression
import re
p = re.compile('[a-z]+')   # '패턴 객체' 를 생성한다.

# 패턴 객체에는 아래 4 가지 메서드를 사용할 수 있다.
# match(), search(), findall(), finditer()
'''

# match()   : 문자열의 처음부터 정규식과 Matching되는지 조사한다.
'''
import re
p = re.compile('[a-z]+')
# m = p.match("Python 3")   --> Match되지 않으므로 None이 출력된다.
m = p.match("python")
print(m)
# -->   <re.Match object; span=(0, 6), match='python'>  이런 식으로 match 객체가 출력된다.
'''

# search()  : Match와 같이 정규식과의 Matching 결과를 출력하나, 문자열 중간에서부터 match 되는지까지 모두 검사한다.
'''
import re
p = re.compile('[a-z]+')
m = p.search("12 python 3")
print(m)
# --> <re.Match object; span=(3, 9), match='python'>    문자열의 3 ~ 9 번째 요소가 match된다는 것을 확인할 수 있다.
'''

# findall()
'''
import re
p = re.compile('[a-z]+')
result = p.findall("life is too short")
print(result)
# --> ['life', 'is', 'too', 'short']    Match되는 모든 값을 찾아 List 형태로 출력한다.
'''

# finditer()    : findall과 동일하나 '반복가능한 객체(iter)' 를 return 한다. (반복 가능 객체 == match 객체)
'''
import re
p = re.compile('[a-z]+')
result = p.finditer("life is too short")
print(result)
# --> <callable_iterator object at 0x000002B69907A9B0>  match 객체가 return 됨을 확인할 수 있다.
for r in result:
    print(r)
    """ --> 아래와 같이 match 객체들로 나오는 것을 확인할 수 있다.
    <re.Match object; span=(0, 4), match='life'>
    <re.Match object; span=(5, 7), match='is'>
    <re.Match object; span=(8, 11), match='too'>
    <re.Match object; span=(12, 17), match='short'>
    """
'''


# match 객체의 메서드
# group(), start(), end(), span()
'''
import re
p = re.compile('[a-z]+')
# m = p.match("python")
m = p.search("3 python")
print(m.group())    # python    return : 매치된 문자열
print(m.start())    # 2         return : 시작 위치
print(m.end())      # 8         return : 끝 위치
print(m.span())     # (2, 8)    return : 시작, 끝 tuple
'''

# 정규식 컴파일 옵션 (괄호 안은 줄임 표현)
# DOTALL(S), IGNORECASE(I), MULTILINE(M), VERBOSE(X)

# DOTALL(S) : . 메타 문자 -> \n 제외 모두 매치가 되나, \n도 포함하여 매치하고 싶다면 re.DOTALL or re.s 옵션을 사용하여 컴파일 한다.
'''
import re
p = re.compile('a.b', re.DOTALL)
m = p.match('a\nb')
print(m)
# --> <re.Match object; span=(0, 3), match='a\nb'>
'''

# IGNORECASE(I) : 대/소문자 상관 없이 match 원할 때 사용
'''
import re
p = re.compile('[a-z]+', re.IGNORECASE)
print(p.match('python'))    # <re.Match object; span=(0, 6), match='python'>
print(p.match('Python'))    # <re.Match object; span=(0, 6), match='Python'>
print(p.match('PYTHON'))    # <re.Match object; span=(0, 6), match='PYTHON'>
'''

# MULTILINE(M)  : ^와 $와 연관된 옵션
    # ^ : 문자열의 처음     (^python --> 문자열 시작 항상 python ~)
    # $ : 문자열의 마지막   (python$ --> 문자열 마지막 항상 ~ python)
'''
import re
p = re.compile("^python\s\w+", re.MULTILINE)

data = """python one
life is too short
python two
you need python
python three
"""
print(p.findall(data))  # 줄바꿈 option이 없을 경우 ['python one'] 하나만 출력 된다.
# --> ['python one', 'python two', 'python three']
'''

# VERBOSE(X)    : 문자열에 사용된 WhiteSpace가 컴파일할 때 제거된다. (어려운 정규식을 주석 또는 줄 단위로 구분하기 위함, [] 안의 WhiteSpace는 제거되지 않음)
'''
import re
charref = re.compile(r'&[#](0[0-7]+|[0-9]+|x[0-9a-fA-F]+);')

# 위의 정규식을 VERBOSE 활용 아래처럼 바꿔줄 수 있다
charref = re.compile(r"""
&[#]                # Start of a numeric entity reference
 (
     0[0-7]+        # Octal form
   | [0-9]+         # Decimal form
   | x[0-9a-fA-F]+  # Hexadecimal form
 )
 ;                  # Trailing semicolon
""", re.VERBOSE)
'''


# 역슬래시 문제
# 예로, "\section"을 찾기 위한 정규식을 만들 때
# \s 는 whitespace(띄워쓰기) 로 인식되어 의도한 대로 match되지 않는다.
# [ \t\n\r\f\v]ection 와 동일한 의미.
# 의도한 대로라면 \\section 으로 변경해야 한다.

# 이걸 또 \ 가 문자열 자체라는 것을 알려주기 위해 앞에 \\ 를 추가해야 한다.
# --> p = re.compile('\\\\section') 이 되어야 한다!
import re
p = re.compile('\\\\section')

# 역슬래시 4개 너무 비효율 적이라, raw string을 활용한다.
p = re.compile(r'\\section')
# 문자열 앞에 r 을 추가하게 되면 해당 문자열은 내용 그대로 문자열이라는 것을 뜻한다.

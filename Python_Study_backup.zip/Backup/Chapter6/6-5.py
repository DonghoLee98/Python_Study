
# Tab 문자 --> Space 4 개로 바꾸기

'''
- 필요한 기능
    문서 파일 읽어들이기
    문자열 변경하기
- 입력값
    (탭을 포함한)문서 파일
- 출력값
    수정 후의 문서 파일
'''

# 다음과 같이 수행한다.
# tapto4.py를 실행하여 a.txt를 input으로 받고 b.txt를 output으로 출력한다.
# python tapto4.py a.txt b.txt




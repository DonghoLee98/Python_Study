
# 메모장 만들기

'''
- 필요한 기능
    메모 추가하기
    메모 조회하기

- 입력받는 값
    메모 내용
    프로그램 실행 옵션...

- 출력하는 값
    memo.txt (파일 형식)
'''

# 메모 입력하기
# python memo.py -a "Life is too short"

# 메모 출력하기
# python memo.py '-v'


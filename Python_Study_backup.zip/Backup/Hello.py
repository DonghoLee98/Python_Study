print("Hello World!")

print("Hello")
print("World")
# 한 줄 주석은 다음과 같다 : Command + ?
# 여러줄 주석은 ''' 또는 """ 을 사용한다.


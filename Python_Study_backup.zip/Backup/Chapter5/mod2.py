# /Users/hodong/Documents/Python/Chapter5/mod2.py
# mod2.py
PI = 3.141592

class Math:
    def solv(self, r):
        return PI * (r ** 2)    # 원의 넓이 구하는 공식
    
def add(a, b):
    return a + b
